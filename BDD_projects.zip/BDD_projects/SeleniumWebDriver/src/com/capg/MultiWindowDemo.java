package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MultiWindowDemo {
	public static void main(String[] args) {

		WebDriver driver = WebUtil.getWebDriver();

		driver.get("C:\\BDD WorkSpace\\SeleniumWebDriver\\html\\PopupWin.html");

		String parentWindow = driver.getWindowHandle();
		driver.findElement(By.name("Open")).click();

		driver.switchTo().window("PopupWindow");
		driver.findElement(By.name("txtName")).sendKeys("Niraj");
		driver.findElement(By.name("btnAlert")).click();
		driver.switchTo().alert().accept();
		
		
		driver.close();
		driver.switchTo().window(parentWindow);
		
		driver.close();

	}
}