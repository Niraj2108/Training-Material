package com.capg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebElementDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
WebDriver driver  = WebUtil.getWebDriver();
        
        driver.navigate().to("https://www.toolsqa.com/automation-practice-form");
        WebElement link1 =    driver.findElement(By.partialLinkText("SELENIUM"));
        link1.click();
        
        driver.navigate().back();
        
        /*WebElement link2 =    driver.findElement(By.linkText("ABOUT"));
        link2.click();*/
        
       /* WebElement gender =    driver.findElement(By.id("sex-0"));
        gender.click();*/
        
        
        
		
	}

}
