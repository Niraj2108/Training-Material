package com.capg.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageObjectRepository {

	@FindBy(id = "userName")
	@CacheLookup
	WebElement userField;

	@FindBy(how = How.ID, using = "password")
	@CacheLookup
	WebElement passwordField;
	
	@FindBy(id = "loginButton")
	@CacheLookup
	WebElement loginButton;
	
	
	public PageObjectRepository(WebDriver driver ) {
		
		PageFactory.initElements(driver, this);
		
	}

	public WebElement getUserField() {
		return userField;
	}

	public void setUserField(WebElement userField) {
		this.userField = userField;
	}

	public WebElement getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton(WebElement loginButton) {
		this.loginButton = loginButton;
	}

	

}
