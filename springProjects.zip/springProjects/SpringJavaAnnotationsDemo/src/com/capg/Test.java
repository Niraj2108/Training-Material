package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class Test {

	@Autowired
	static EmpService service;
	

	public static EmpService getService() {
		return service;
	}


	public static void setService(EmpService service) {
		Test.service = service;
	}


	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext  context = new AnnotationConfigApplicationContext();
		
		
		System.out.println("EmpService " + service);
		
		context.scan("com.capg");
		context.refresh();
		
		Employee emp1 = context.getBean("emp",Employee.class);
		Employee emp2 = context.getBean("emp",Employee.class);
		
	//	emp.setEname("Niraj");
		System.out.println(emp1.getAddress());
		System.out.println(emp2);
	}
	
	/*
	 * @Bean(name="e1") // @Scope("prototype")
	 * 
	 * @Scope("singleton")
	 * 
	 * public Employee getEmpObj() {
	 * 
	 * return new Employee(); }
	 */
	
}
