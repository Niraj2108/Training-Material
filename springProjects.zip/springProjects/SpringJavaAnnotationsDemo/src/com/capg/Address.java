package com.capg;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class Address {

	private String city;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	
}
