import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';


@Component({
  selector: 'app-display-employee',
  templateUrl: './display-employee.component.html',
  styleUrls: ['./display-employee.component.css']
})
export class DisplayEmployeeComponent implements OnInit {

  constructor(private _service: EmployeeService) { }

  empList: Employee[] = [];

  ngOnInit() {

    this.getAllEmployee();
  }

  getAllEmployee() {

    this._service.getAllEmployees().subscribe(data => this.empList = data);

   }
}
