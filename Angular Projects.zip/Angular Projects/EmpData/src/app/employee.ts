

export interface Employee {

  eid: number;
  ename: string;
  email: string;
  phone: number;

}
