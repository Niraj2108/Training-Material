import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private _service: EmployeeService) { }
  empList: Employee[] = [];

  isValid = false;

 showProduct(i) {
   this.isValid = true;
 }

  ngOnInit() {
  }

  addEmployee(addform) {

    this.empList.push(addform.value);

  }


}
