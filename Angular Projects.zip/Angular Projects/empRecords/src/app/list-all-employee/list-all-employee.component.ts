import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-list-all-employee',
  templateUrl: './list-all-employee.component.html',
  styleUrls: ['./list-all-employee.component.css']
})
export class ListAllEmployeeComponent implements OnInit {

  employeeServiceObj: EmployeeService = new EmployeeService();
  empList: Employee[] = [];

  constructor() { }

  ngOnInit() {
    this.empList = this.employeeServiceObj.listEmployeeService();
  }

  deleteEmployee(i) {
    if (confirm("Are you sure to delete ")) {
      console.log( this.employeeServiceObj.deleteEmployeeService(i));
    }
  }
}
