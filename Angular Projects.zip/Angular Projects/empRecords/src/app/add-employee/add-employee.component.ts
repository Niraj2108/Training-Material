import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../Employee';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  empServiceObj: EmployeeService = new EmployeeService();
  employeeList: Employee[];

  constructor() { }

  ngOnInit() {
  }

  addEmployee(addForm) {
    this.empServiceObj.addEmployeeService(addForm);
    alert('Employee Added.');
    // console.log(this.employeeList);
  }

}
