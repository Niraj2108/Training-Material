
export class Products {
  ProductId: number;
  Category: string;
  MainCategory: string;
  TaxTarifCode: number;
  SupplierName: string;
// tslint:disable-next-line:eofline
}
