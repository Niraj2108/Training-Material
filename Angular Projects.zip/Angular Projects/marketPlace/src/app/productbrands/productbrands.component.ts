import { Component, OnInit } from '@angular/core';
import {Products} from '../products';
import {ProductService} from '../product.service';
@Component({
  selector: 'app-productbrands',
  templateUrl: './productbrands.component.html',
  styleUrls: ['./productbrands.component.css']
})
export class ProductbrandsComponent implements OnInit {
  [x: string]: any;

  productsData: Products[];
  constructor(private _ProductService: ProductService) { }

  ngOnInit() {
    this._ProductService.getAllMobileDetail().
    subscribe((data: Products[]) => this.productsData = data);
  }

}
