import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(private service: ProductService) { }

  proList: Product[];
  proList1: Product[] = [];
  //product: Product;

  ngOnInit() {
    this.getProducts();
  }

  getProducts() {
    this.service.getProducts().subscribe(data => this.proList = data);
  }

  submit(val) {
    this.proList1=[];
    let j=0;
    for(let i=0;i<this.proList.length;i++) {
      if((val.value.category == this.proList[i].category)||(val.value.category == this.proList[i].name )) {
        this.proList1[j] = this.proList[i];
        j++;
      }
    }
  }
}
