import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

registerForm: FormGroup;
submitted = false;

username: string;
password: string;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
this.registerForm = this.formBuilder.group({

    username: ['', [Validators.required, Validators.minLength(4)]],
    password: ['', [Validators.required, Validators.pattern('[A-Z]{5}')]]

});


  }
  get f() {
    return this.registerForm.controls;
    }

    onSubmit(data) {
      this.submitted = true;

      if (this.registerForm.invalid) {
        return;
      }

      alert('Form submitted Successfully');

      this.username = data.username;
      this.password = data.password;
    }
}
