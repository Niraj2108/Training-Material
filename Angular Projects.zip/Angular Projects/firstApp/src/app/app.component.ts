import { Component, Input } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Niraj, How are you';



  parentValue : string = 'Bhagvan Ko Mante Ho';

id: number=21;
name:string='Goku';
isValid=true;
value:any = 'any value';

image='assets/train1.jpg';
image2='assets/train2.jpg';


city:string ='Nagpur';

 sayHello() {
   alert('Hello Friends..');

}
getData(value) {
  alert(value);

}

}
