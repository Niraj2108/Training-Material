import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }

  student = {'sid': '101' , 'sname': 'niraj' , 'course': 'java'};

  getStudent() {
    console.log('hi, this is student getter');
  }
}
