import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directives',
  templateUrl: './directives.component.html',
  styleUrls: ['./directives.component.css']
})
export class DirectivesComponent implements OnInit {

  myName = 'Niraj';
  isValid = false;

jsondata = {id: '101', name: 'niraj', slary: 5000 };

cities = ['Nagpur', 'Pune', 'Mumbai', 'Hyedrabad'];

choice: string;

  constructor() { }

  ngOnInit() {
  }

}
