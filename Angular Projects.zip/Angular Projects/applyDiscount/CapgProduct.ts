export class CapgProduct
{
 productAvailability:boolean;
 productBrand:String;
 productCategory:String;
 productDiscount:number;
 productFeedback:String;
 productId:number;
 productImage:String;
 productName:String;
 productPrice:number;
 productQuantity:number;
 productRating:number;
 productType:String;
 merchantId:number;
 finalPrice:number
}
