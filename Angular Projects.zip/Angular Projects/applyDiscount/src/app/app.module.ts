import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';


import { AppComponent } from './app.component';
import { DiscountComponent } from './discount/discount.component';
import { DiscountService } from './discount.service';

@NgModule({
  declarations: [
    AppComponent,
    DiscountComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [DiscountService],
  bootstrap: [DiscountComponent]
})
export class AppModule { }
