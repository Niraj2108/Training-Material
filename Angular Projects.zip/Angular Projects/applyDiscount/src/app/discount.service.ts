import { Injectable } from '@angular/core';
import { Observable } from '../../node_modules/rxjs';
import { CapgProduct } from 'CapgProduct';
import { HttpClient } from '../../node_modules/@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DiscountService {

  constructor(private http: HttpClient) { }
  calculateDiscount(productId): Observable<any> {
    return this.http.put<CapgProduct>('http://localhost:9090/products/' + productId, '');
    }
}
