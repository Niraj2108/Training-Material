import { Component, OnInit } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { CapgProduct } from 'CapgProduct';
import { DiscountService } from '../discount.service';


@Component({
  selector: 'app-discount',
  templateUrl: './discount.component.html',
  styleUrls: ['./discount.component.css']
})
export class DiscountComponent implements OnInit {
id: number;
product: CapgProduct;
  constructor(private service: DiscountService) { }

  ngOnInit() {
  }
  calculateDiscount(discountForm) {
  this.id = discountForm.box1;
  return this.service.calculateDiscount(this.id).subscribe(data => this.product = data);
  }

}
