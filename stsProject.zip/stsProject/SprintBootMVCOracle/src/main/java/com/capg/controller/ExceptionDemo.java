package com.capg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.bean.ErrorInfo;

@ControllerAdvice
public class ExceptionDemo {
	
@ResponseBody
@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Employee Not Found")
@ExceptionHandler(value= {Exception.class})
protected ErrorInfo handleConflict(Exception ex, HttpServletRequest req) {
	
	String bodyOfResponse = ex.getMessage();
	String uri = req.getRequestURI().toString();
	return new ErrorInfo(uri,bodyOfResponse);
}


}
