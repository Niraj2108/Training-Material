package com.capg.exception;

public class EmployeeExp extends Exception {

}
