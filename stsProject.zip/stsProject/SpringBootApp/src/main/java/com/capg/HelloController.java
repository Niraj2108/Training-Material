package com.capg;

import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController													//it can return message
public class HelloController {
	
	@RequestMapping("/display")
	@ResponseBody
	public String display() {
		
		
		return "display.jsp";
	}

}
