package com.capgemini.capstore.dao;

import com.capgemini.capstore.beans.CapgProduct;


/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is Dao interface.
 */
public interface CapgProductDao {

	public double getPrice(int productId);

	public double getDiscount(int productId);
	public CapgProduct calculateDiscount(int productId);

	//public void addProduct(CapgProduct p);
}
