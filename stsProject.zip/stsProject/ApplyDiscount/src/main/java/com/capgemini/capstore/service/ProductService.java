package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.dao.CapgProductDaoImpl;

/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is service class which contains calculateDiscount method.
 */

@Service
public class ProductService implements ProductServiceIntf {

	@Autowired
	CapgProductDaoImpl productDao;

	double finalCalculatedPrice;
	double discountPrice;
	double price;
	double discount;
	@Override
	public CapgProduct calculateDiscount(int productId) {
		// TODO Auto-generated method stub
		
		return productDao.calculateDiscount(productId);
		
	}

	//public double calculateDiscount(int productId) {

	/*	CapgProduct p = new CapgProduct();
		p.setProductId(101);
		p.setProductDiscount(10);
		p.setProductPrice(100);
		productDao.addProduct(p);
		*/
		//*CapgProduct p = new CapgProduct();
		//price = productDao.getPrice(productId);
	//	discount = productDao.getDiscount(productId);
																							// from this
	//	discountPrice = (price * discount) / 100;
	//	finalCalculatedPrice=  price - discountPrice;
		// p.setFinalPrice(finalCalculatedPrice);
		 
		//return finalCalculatedPrice;
	
	

}