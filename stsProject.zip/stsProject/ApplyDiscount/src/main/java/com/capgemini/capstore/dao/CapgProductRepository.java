package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.CapgProduct;
/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is Repository interface which extends JpaRepository 
 */

@Repository
public interface CapgProductRepository extends JpaRepository<CapgProduct,Integer>  {
	
	
	/*@Query("select product_price from CapgProduct where productId : productId")  
	double getPrice(@Param("productId") int productId);
	@Query("select product_discount from CapgProduct where productId : productId")
	double getDiscount(@Param("productId") int productId);
*/
}
