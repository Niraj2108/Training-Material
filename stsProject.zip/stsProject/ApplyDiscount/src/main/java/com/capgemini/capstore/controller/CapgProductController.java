package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.CapgProduct;
import com.capgemini.capstore.service.ProductServiceIntf;

/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is controller class 
 */

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class CapgProductController {

	@Autowired
	ProductServiceIntf service;
	
	
	@PutMapping("/products/{productId}")
	public CapgProduct calculateDiscount(@PathVariable int productId) {
		
		
		 return service.calculateDiscount(productId);
	}
	
}
