package com.capgemini.capstore.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.CapgProduct;

/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is Dao implementation class which implements Dao interface 
 */

@Service
public class CapgProductDaoImpl implements CapgProductDao {

	@Autowired
	CapgProductRepository productRepo;

	double finalCalculatedPrice;
	double discountPrice;
	double price1;
	double discount;

	CapgProduct product = new CapgProduct();

	// This method will get the price from the stored database based on productId.
	
	public double getPrice(int productId) {

		product = productRepo.findById(productId).orElse(null);
		price1 = product.getProductPrice();
		return price1;
	}

	// This method will get the discount from the stored database based on productId.
	
	public double getDiscount(int productId) {
		product = productRepo.findById(productId).orElse(null);
		discount = product.getProductDiscount();
		return discount;
	}

	// This method will calculate the discount with the help of price and discount from above methods based on productId.
	
	public CapgProduct calculateDiscount(int productId) {

		price1 = getPrice(productId);
		discount = getDiscount(productId);
		if(discount==0) {
			product.setFinalPrice(price1);
		}
		else {
		discountPrice = (price1 * discount) / 100;
		finalCalculatedPrice = price1 - discountPrice;
		product.setFinalPrice(finalCalculatedPrice);
		}
	return	productRepo.save(product);

	}
}
