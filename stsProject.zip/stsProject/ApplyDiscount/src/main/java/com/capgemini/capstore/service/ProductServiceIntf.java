package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.CapgProduct;

/**
 * @author Niraj Bhoyar
 * @Date  14/10/2019
 * @Description This is  prodcutService interface.
 */

public interface ProductServiceIntf {

	public CapgProduct calculateDiscount(int productId);
}
