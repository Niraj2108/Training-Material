package com.capg;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DisplayController {
	@Autowired
	Employee emp;

	@RequestMapping(value = "/")
	public String form() {

		return "form";
	}

	// @RequestMapping("/display")
	@PostMapping("/display")
	public ModelAndView display(Employee emp) {  //remove request param and use ModelAndView

			ModelAndView mv = new ModelAndView();
			mv.addObject("emp",emp);
			mv.setViewName("display");
		
		// public String display(@RequestParam("eid") int eid, @RequestParam("ename")
		// String ename,@RequestParam("salary") double salary, Model m) {
		/*
		 * int eid = Integer.parseInt(request.getParameter("eid")); 
		 * String ename=request.getParameter("ename"); 
		 * double salary= Double.parseDouble(request.getParameter("salary"));
		 */

		/*
		 * emp.setEid(eid); emp.setEname(ename); emp.setSalary(salary);
		 * 
		 * m.addAttribute("emp",emp);
		 */

		// session.setAttribute("emp", emp);

		return mv;

	}

}
