package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.bean.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer>{
	
	@Query("from Order where quantity between :min and :max")  
	List<Order> getOrdersByRange(@Param("min") int min,@Param("max") int max);
	@Query("from Order where amount>:enteredAmount")
	 List<Order> getOrdersByAmount(@Param("enteredAmount") double enteredAmount);
	
	

}
