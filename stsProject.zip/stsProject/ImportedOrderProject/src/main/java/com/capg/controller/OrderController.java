package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Order;
import com.capg.exception.OrderException;
import com.capg.service.OrderService;


@RestController
public class OrderController {
	
	@Autowired
	OrderService service;
	
	
	@PostMapping(value="/orders", consumes= {"application/json"})
	public List<Order> createOrder(@Valid @RequestBody Order order) throws OrderException {
		
		service.createOrder(order);
		return  service.listAllOrder();
		
	}
	
	@GetMapping(value="/orders")
	public List<Order> listAllOrder() throws OrderException  {
		return service.listAllOrder();
		
	}
	
	@PutMapping(path="/orders")
	public Order updateOrder(@RequestBody Order order) {
		
		return service.updateOrder(order);
		}

	@GetMapping("/orders/{min}/{max}")
	public List<Order> getOrderByRange(@PathVariable int min,@PathVariable int max) {
		return service.getOrdersByRange(min, max);
	}
	
	
	@GetMapping("/orders/{amount}")
	public List<Order> getOrderByAmount(@PathVariable double amount) {
		return service.getOrdersByAmount(amount);
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	
}
