package com.capg.service;

import java.util.List;

import com.capg.bean.Order;
import com.capg.exception.OrderException;

public interface OrderService {
	
	public List<Order> createOrder(Order order);
	
	public Order updateOrder(Order order);
	
	public List<Order> listAllOrder() throws OrderException;
	
	
	public List<Order> getOrdersByRange(int min, int max);
	
	public  List<Order> getOrdersByAmount(double enteredAmount);
	

}
