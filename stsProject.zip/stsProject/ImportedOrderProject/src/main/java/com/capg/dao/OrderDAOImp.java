package com.capg.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Order;
import com.capg.dao.OrderRepository;
import com.capg.exception.OrderException;


@Service
public class OrderDAOImp implements OrderDAO{

	@Autowired
	OrderRepository repo;
	
	/*
	 * Method name: listAllOrder
	 * @return value : List of Orders
	  description : View all Orders
	 */
	
	@Override
	public List<Order> listAllOrder() throws OrderException{
		
		try {
			return repo.findAll();
		} catch (Exception e) {
			throw new OrderException(e.getMessage());
		}
		
	}

	/*
	 * Method name: updateOrder
	 * @return value : Order Values
	  description : update all Orders
	 */
	@Override
	public Order updateOrder(Order order) {
	 	return repo.save(order);
	 		
	}
	
	
	/*
	 * Method name: getOrdersByRange
	 * @return value : List of Orders
	  description : Get Orders By Range
	 */
	@Override
	public List<Order> getOrdersByRange(int min, int max) {
		return repo.getOrdersByRange(min, max);
	}

	
	/*
	 * Method name: getOrdersByAmount
	 * @return value : List of Orders
	  description : Get Orders By Amount
	 */
	
	@Override
	public List<Order> getOrdersByAmount(double enteredAmount) {
		return repo.getOrdersByAmount(enteredAmount);
	}

	
	/*
	 * Method name: createOrder
	 * @return value : List of Orders
	  description : Add Data In Table
	 */
	
	@Override
	public List<Order> createOrder(Order order) {
		// TODO Auto-generated method stub
		double convertedAmount = order.getPrice() * 75 * order.getQuantity();
		double charges = convertedAmount*(00.125)/100;
		double totalAmount = convertedAmount + charges;
		  order.setCharges(charges);
		order.setAmount(totalAmount);
		
      
		
		repo.save(order);
		return repo.findAll();
	
	}

}
