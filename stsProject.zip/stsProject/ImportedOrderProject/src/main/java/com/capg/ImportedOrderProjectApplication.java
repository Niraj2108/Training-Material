package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImportedOrderProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImportedOrderProjectApplication.class, args);
	}

}
