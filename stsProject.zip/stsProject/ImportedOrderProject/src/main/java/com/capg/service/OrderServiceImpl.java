package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Order;
import com.capg.dao.OrderDAO;
import com.capg.exception.OrderException;

@Service
public class OrderServiceImpl implements OrderService{

	/*@Autowired
	OrderRepository repo;*/
	
	@Autowired
	OrderDAO dao;
	
	
	@Override
	public List<Order> listAllOrder() throws OrderException  {
		//return repo.findAll();
		
		return dao.listAllOrder();
	}

	
	@Override
	public Order updateOrder(Order order) {
	 	//return repo.save(order);
		
		return dao.updateOrder(order);
		
	}

	@Override
	public List<Order> getOrdersByRange(int min, int max) {
		//return repo.getOrdersByRange(min, max);
		
		return dao.getOrdersByRange(min, max);
	}

	@Override
	public List<Order> getOrdersByAmount(double enteredAmount) {
		//return repo.getOrdersByAmount(enteredAmount);
		
		return dao.getOrdersByAmount(enteredAmount);
	}

	@Override
	public List<Order> createOrder(Order order) {
		
		return dao.createOrder(order);
	
	}

}
